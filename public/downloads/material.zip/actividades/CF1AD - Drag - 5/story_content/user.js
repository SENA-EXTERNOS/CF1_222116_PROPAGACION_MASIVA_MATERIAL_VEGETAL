function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6SkZ0eCUsAc":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

